﻿namespace BaiduMapTileCutter
{
    partial class StepPanel7
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbx7 = new System.Windows.Forms.GroupBox();
            this.lblLayerConfigConfirm = new System.Windows.Forms.Label();
            this.lblLevelInfoConfirm = new System.Windows.Forms.Label();
            this.lblCenter = new System.Windows.Forms.Label();
            this.lblOutputType = new System.Windows.Forms.Label();
            this.tbxOutputPath = new System.Windows.Forms.TextBox();
            this.tbxImagePath = new System.Windows.Forms.TextBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.lblCutHint = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.progressTimer = new System.Windows.Forms.Timer(this.components);
            this.gbx7.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbx7
            // 
            this.gbx7.Controls.Add(this.lblLayerConfigConfirm);
            this.gbx7.Controls.Add(this.lblLevelInfoConfirm);
            this.gbx7.Controls.Add(this.lblCenter);
            this.gbx7.Controls.Add(this.lblOutputType);
            this.gbx7.Controls.Add(this.tbxOutputPath);
            this.gbx7.Controls.Add(this.tbxImagePath);
            this.gbx7.Controls.Add(this.progressBar);
            this.gbx7.Controls.Add(this.lblCutHint);
            this.gbx7.Controls.Add(this.label35);
            this.gbx7.Controls.Add(this.label34);
            this.gbx7.Controls.Add(this.label33);
            this.gbx7.Controls.Add(this.label32);
            this.gbx7.Controls.Add(this.label31);
            this.gbx7.Controls.Add(this.label30);
            this.gbx7.Controls.Add(this.label29);
            this.gbx7.Controls.Add(this.label28);
            this.gbx7.Location = new System.Drawing.Point(3, 3);
            this.gbx7.Name = "gbx7";
            this.gbx7.Size = new System.Drawing.Size(519, 390);
            this.gbx7.TabIndex = 12;
            this.gbx7.TabStop = false;
            // 
            // lblLayerConfigConfirm
            // 
            this.lblLayerConfigConfirm.AutoSize = true;
            this.lblLayerConfigConfirm.Location = new System.Drawing.Point(83, 252);
            this.lblLayerConfigConfirm.Name = "lblLayerConfigConfirm";
            this.lblLayerConfigConfirm.Size = new System.Drawing.Size(0, 12);
            this.lblLayerConfigConfirm.TabIndex = 23;
            // 
            // lblLevelInfoConfirm
            // 
            this.lblLevelInfoConfirm.AutoSize = true;
            this.lblLevelInfoConfirm.Location = new System.Drawing.Point(83, 224);
            this.lblLevelInfoConfirm.Name = "lblLevelInfoConfirm";
            this.lblLevelInfoConfirm.Size = new System.Drawing.Size(0, 12);
            this.lblLevelInfoConfirm.TabIndex = 22;
            // 
            // lblCenter
            // 
            this.lblCenter.AutoSize = true;
            this.lblCenter.Location = new System.Drawing.Point(83, 196);
            this.lblCenter.Name = "lblCenter";
            this.lblCenter.Size = new System.Drawing.Size(29, 12);
            this.lblCenter.TabIndex = 21;
            this.lblCenter.Text = "0, 0";
            // 
            // lblOutputType
            // 
            this.lblOutputType.AutoSize = true;
            this.lblOutputType.Location = new System.Drawing.Point(83, 168);
            this.lblOutputType.Name = "lblOutputType";
            this.lblOutputType.Size = new System.Drawing.Size(65, 12);
            this.lblOutputType.TabIndex = 20;
            this.lblOutputType.Text = "图块和代码";
            // 
            // tbxOutputPath
            // 
            this.tbxOutputPath.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tbxOutputPath.Enabled = false;
            this.tbxOutputPath.Location = new System.Drawing.Point(85, 135);
            this.tbxOutputPath.Name = "tbxOutputPath";
            this.tbxOutputPath.Size = new System.Drawing.Size(422, 21);
            this.tbxOutputPath.TabIndex = 10;
            // 
            // tbxImagePath
            // 
            this.tbxImagePath.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tbxImagePath.Enabled = false;
            this.tbxImagePath.Location = new System.Drawing.Point(85, 108);
            this.tbxImagePath.Name = "tbxImagePath";
            this.tbxImagePath.Size = new System.Drawing.Size(422, 21);
            this.tbxImagePath.TabIndex = 11;
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(15, 353);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(492, 23);
            this.progressBar.Step = 1;
            this.progressBar.TabIndex = 19;
            // 
            // lblCutHint
            // 
            this.lblCutHint.AutoSize = true;
            this.lblCutHint.Font = new System.Drawing.Font("宋体", 11F);
            this.lblCutHint.Location = new System.Drawing.Point(14, 321);
            this.lblCutHint.Name = "lblCutHint";
            this.lblCutHint.Size = new System.Drawing.Size(67, 15);
            this.lblCutHint.TabIndex = 18;
            this.lblCutHint.Text = "准备就绪";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(18, 252);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 17;
            this.label35.Text = "图层设置：";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(18, 224);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 12);
            this.label34.TabIndex = 16;
            this.label34.Text = "级别设置：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(18, 196);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 12);
            this.label33.TabIndex = 15;
            this.label33.Text = "中心坐标：";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(18, 168);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 14;
            this.label32.Text = "输出类型：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(18, 140);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 13;
            this.label31.Text = "输出路径：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(18, 112);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 12;
            this.label30.Text = "图片路径：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(17, 70);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(341, 12);
            this.label29.TabIndex = 11;
            this.label29.Text = "点击“开始切图”进行切图，点击“上一步”返回修改配置信息";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 11F);
            this.label28.Location = new System.Drawing.Point(13, 20);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(67, 15);
            this.label28.TabIndex = 10;
            this.label28.Text = "开始切图";
            // 
            // progressTimer
            // 
            this.progressTimer.Tick += new System.EventHandler(this.progressTimer_Tick);
            // 
            // StepPanel7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbx7);
            this.Name = "StepPanel7";
            this.Size = new System.Drawing.Size(530, 400);
            this.gbx7.ResumeLayout(false);
            this.gbx7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx7;
        private System.Windows.Forms.Label lblLayerConfigConfirm;
        private System.Windows.Forms.Label lblLevelInfoConfirm;
        private System.Windows.Forms.Label lblCenter;
        private System.Windows.Forms.Label lblOutputType;
        private System.Windows.Forms.TextBox tbxOutputPath;
        private System.Windows.Forms.TextBox tbxImagePath;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label lblCutHint;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Timer progressTimer;
    }
}
