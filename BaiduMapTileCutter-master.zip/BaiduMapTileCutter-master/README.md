# TileCutter 

百度地图切图工具

## 安装

在项目目录中找到BaiduMapTileCutter\bin\Release\BaiduMapTileCutter.exe，下载即可执行。

## 使用教程

[教程地址](http://www.jiazhengblog.com/blog/2011/10/08/422/)

注意：文章是基于老版本工具编写的，新版本工具可能略有差别，但总体使用方式一样。

## 如何修改

Clone 整个项目，使用 Visual Studio 打开解决方案文件 BaiduMapTileCutter.sln